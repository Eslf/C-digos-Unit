package Vetor;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Vetor<T> implements IVetor<T>, Iterable<T> {

	private final int tamVetor; // por padr�o � 10
	private T[] elementos; // como instanciar: (T[]) new Object[tamVetor]
	private int contElementos; // contador de elementos
	private int vlIncremento; // valor para redimensionar, por padr�o o valor �
								// 10
private String nome;
	// implemente os 3 construtores!

	// Construtor Default e Incremento
	public Vetor(String nome,int tamVetor, int vlIncremento) {
		this.tamVetor = tamVetor;
		this.vlIncremento = vlIncremento;
		this.elementos = (T[]) new Object[tamVetor];
	        this.nome=nome;
        }

	private Iterator<T> myIterator = new Iterator<T>() {

		private int posicao = 0;

		@Override
		public boolean hasNext() {
			if (posicao < contElementos) {
				return true;
			} else {
				return false;
			}
		}

		@Override
		public T next() throws NoSuchElementException {
			if (!hasNext()) {
				throw new NoSuchElementException();
			} else {
				T elemento = elementos[posicao];
				posicao++;
				return elemento;
			}
		}
	};

	@Override
	public Iterator<T> iterator() {
		return myIterator;
	}

	// add elementos na ultima posi�ao
	@Override
	public void Adicionar(T elemento) {
		for (int i = 0; i < this.tamVetor; i++) {
			if (this.elementos[i] == null) {
				this.elementos[i] = elemento;
				contElementos++;
				break;

			}
		}

	}

	// add em uma posi��o especifica
	@Override
	public void Adicionar(int posicao, T elemento) throws IndexOutOfBoundsException {
		if (this.elementos[posicao] == null) {
			this.elementos[posicao] = elemento;
			contElementos++;
		} else {
			for (int i = posicao + 1; i < this.elementos.length; i++) {
				if (this.elementos[i] == null) {
					this.elementos[i] = this.elementos[posicao];
					this.elementos[posicao] = elemento;
					contElementos++;
					break;
				}

			}

		}
	}

	@Override
	public void AdicionarInicio(T elemento) {
		if (contElementos + 1 > this.elementos.length) {
			T[] maior = (T[]) new Object[tamVetor + 1];
			System.arraycopy(elemento, 0, maior, 1, this.elementos.length);
			maior[0] = elemento;
		} else {
			T[] maior = (T[]) new Object[tamVetor];
			System.arraycopy(this.elementos, 0, maior, 1, this.elementos.length);
			maior[0] = elemento;
		}
	}

	@Override
	public void Remover(int posicao) throws IndexOutOfBoundsException {
		this.elementos[posicao] = null;
		this.contElementos--;
		for (int i = posicao; i < this.contElementos; i++) {
			this.elementos[i] = this.elementos[i + 1];

		}

	}

	@Override
	public void RemoverElemento(T elemento) {
		// TODO Auto-generated method stub

	}

	@Override
	public void RemoverInicio() {
		this.elementos[0] = null;

	}

	@Override
	public void RemoverFim() {
		this.elementos[this.contElementos - 1] = null;
		this.contElementos--;

	}

	@Override
	public int Tamanho() {
		System.out.print("tamanho do Vetor " + this.contElementos);
		return 0;
	}

	@Override
	public void Limpar() {
		for (int i = 0; i < this.elementos.length; i++) {
			this.elementos[i] = null;
		}

	}

	@Override
	public boolean contem(T elemento) {
		for (int i = 0; i < this.elementos.length; i++) {
			if (this.elementos[i] == elemento) {
				return true;
			}
		}
		return false;
	}

}