package listasim;

public class PosicaoN�oExisteException extends Exception {
	public PosicaoN�oExisteException() {
		super("Erro: Posi��o digitada n�o existe.");
	}
}
